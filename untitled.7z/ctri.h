#ifndef CTRI_H
#define CTRI_H

#include <QImage>
#include <qglobal.h>
#include "qfilter.h"
#include <ctime>

class CTRI
{
public:
    CTRI();
    CTRI(double);

    bool set_density(double);
    double get_density() const;
    bool** get_map_of_noise() const { return map_of_noise; }
    bool save_map_to_txt_file();

    bool Disturb(QImage &);

private:
    double density;
    bool** map_of_noise;
    int image_size[2];

};

#endif // CTRI_H
