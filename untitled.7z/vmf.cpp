#include "vmf.h"

VMF::VMF()
{
    R=nullptr;
    G=nullptr;
    B=nullptr;

    delay=0;
    filtration_window_size=0;

}

VMF::VMF(int x, int y, double **red, double **green, double **blue, int frame)
{
    R=red;
    B=blue;
    G=green;

    filtration_window_size=frame;
    delay=floor(filtration_window_size/2);

    coordinates[0]=x;
    coordinates[1]=y;
}

bool VMF::filter()
{
    if(R==nullptr)
    {
        return false;
    }
    else
    {

        double minimum =0;
        double temp=0;

        int first_x=coordinates[0]-delay;
        int first_y=coordinates[1]-delay;

        colors[0]=R[first_x][first_y];
        colors[1]=G[first_x][first_y];
        colors[2]=B[first_x][first_y];

        for(int i1= first_x;i1<first_x+filtration_window_size;++i1)
        {
            for(int j1=first_y;j1<first_y+filtration_window_size;++j1)
            {
                temp=0;

                for(int i2= first_x;i2<first_x+filtration_window_size;++i2)
                {
                    for(int j2=first_y;j2<first_y+filtration_window_size;++j2)
                    {

                        if(i1==coordinates[0]-delay&&j1==coordinates[1]-delay)
                            minimum+=(abs(R[i1][j1]-R[i2][j2])+abs(B[i1][j1]-B[i2][j2])+abs(G[i1][j1]-G[i2][j2]));
                        else
                            temp+=abs(R[i1][j1]-R[i2][j2])+abs(B[i1][j1]-B[i2][j2])+abs(G[i1][j1]-G[i2][j2]);
                    }
                }

                if((i1!=coordinates[0]-delay&&j1!=coordinates[1]-delay)&&minimum>temp)
                {
                    minimum=temp;
                    colors[0]=R[i1][j1];
                    colors[1]=G[i1][j1];
                    colors[2]=B[i1][j1];
                }

            }
        }
        return true;
    }
}

bool VMF::detect()
{
    return false;
}

bool VMF::detect_and_filter()
{
    return false;
}
