#ifndef QFILTER_H
#define QFILTER_H

#include <QObject>
#include <QImage>
#include <QColor>

class QFilter
{
public:
    QFilter();
    QFilter(double**,double**,double**,int,int, unsigned short);

    QFilter(QImage&,unsigned short,bool**);
    ~QFilter();


    bool load_the_image(QImage&);
    virtual bool filter()=0;
    virtual bool detect_and_filter()=0;
    virtual bool detect()=0;

    double** get_R() const {return R;}
    double** get_G() const {return G;}
    double** get_B() const {return B;}

    double** get_CIE_l() const {return CIE_l;}
    double** get_CIE_a() const {return CIE_a;}
    double** get_CIE_b() const {return CIE_b;}


    int get_delay() const {return delay;}

    bool calculate_XYZ();
    bool convert_from_XYZ_to_CIElab();


    bool** get_noise_map_pointer() {return noise_map;}


    bool set_filtration_window_size(const unsigned short);
    unsigned short get_filtration_window_size() const {return filtration_window_size;}


    bool set_map(bool**);
    bool set_delay(int value) { delay=value; return true; }
    double Accuracy(bool**);

protected:
    double **R;
    double **G;
    double **B;

    double **X;
    double **Y;
    double **Z;

    double** CIE_l;
    double** CIE_a;
    double** CIE_b;

    int image_size[2];
    unsigned short filtration_window_size;
    int delay;
    bool** noise_map;
};

#endif // QFILTER_H
