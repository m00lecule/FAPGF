#include "clearimage.h"
#include <cmath>

ClearImage::ClearImage() :QFilter()
{
}

ClearImage::ClearImage(QImage & image,unsigned short frame) :QFilter(image,frame,nullptr)
{
}

double ClearImage::calculate_MSE(double** r, double ** g, double** b)
{

    if(r==nullptr)
    {
        return 0.0;
    }
    else
    {
        double mse=0.0;

        for(int i=delay;i<image_size[0]-delay;++i)
        {
            for(int j=delay;j<image_size[1]-delay;++j)
            {
                //dodajemy po każdym kanale, tablica w ClearImage nie ma ramki, wiec w tej z AverageFilter trzeba uwzględnić przesunięcie

                mse+=(R[i][j]-r[i][j])*(R[i][j]-r[i][j]);

                mse+=(B[i][j]-b[i][j])*(B[i][j]-b[i][j]);

                mse+=(G[i][j]-g[i][j])*(G[i][j]-g[i][j]);
            }
        }

        mse*=(1/(3.0*(image_size[0]*image_size[1])));

        return mse;
    }
}

double ClearImage::calculate_PSNR(double** r, double ** g, double ** b)
{

    if(r==nullptr)
    {
        return 0.0;
    }
    else
    {
        double mse=calculate_MSE(r,g,b);

        return 10.0*log10((255*255/mse));
    }
}
double ClearImage::calculate_NCD(double**l, double**a,double**b)
{
    if(CIE_a==nullptr)
        convert_from_XYZ_to_CIElab();

    double sum_of_difference=0;

    double sum=0;

    for(int i=0;i<image_size[0]-2*delay;++i)
    {
        for(int j=0;j<image_size[1]-2*delay;++j)
        {
            sum_of_difference+=sqrt(pow(l[i][j]-CIE_l[i][j],2)+pow(a[i][j]-CIE_a[i][j],2)+pow(b[i][j]-CIE_b[i][j],2));

            sum+=CIE_l[i][j]+CIE_a[i][j]+CIE_b[i][j];
        }

    }


    return (sum_of_difference*1.0/sum);
}

