#include "fapgf.h"
#include <QFile>
#include <QTextStream>
#include <QString>


FAPGF::FAPGF() :QFilter()
{
    Type_of_noise = Noise_Type::CTRI;
    d_parameter=0;
    aux_tab_is_calculated=false;
    aux_table5=nullptr;
    aux_table7=nullptr;
    aux_table9=nullptr;
    aux_table11=nullptr;

    aux_b_table5=nullptr;
    aux_b_table7=nullptr;
    aux_b_table9=nullptr;
    aux_b_table11=nullptr;

   measure_type_unit=Distance::Euklidesaowa;
}

FAPGF::FAPGF(QImage &Image, unsigned short index,Noise_Type NT=Noise_Type::CTRI) :QFilter(Image,index,nullptr), Type_of_noise(NT)
{
    images=Image;
    aux_tab_is_calculated=false;
    aux_table5=nullptr;
    aux_table7=nullptr;
    aux_table9=nullptr;
    aux_table11=nullptr;

    aux_b_table5=nullptr;
    aux_b_table7=nullptr;
    aux_b_table9=nullptr;
    aux_b_table11=nullptr;

    measure_type_unit=Distance::Euklidesaowa;
}

FAPGF::FAPGF(double **red, double **green, double **blue, int width, int height, unsigned short index,Noise_Type NT=Noise_Type::CTRI) :QFilter(red,green,blue,width,height,index)
{
    Type_of_noise=NT;
    aux_tab_is_calculated=false;
    aux_table5=nullptr;
    aux_table7=nullptr;
    aux_table9=nullptr;
    aux_table11=nullptr;

    aux_b_table5=nullptr;
    aux_b_table7=nullptr;
    aux_b_table9=nullptr;
    aux_b_table11=nullptr;

    measure_type_unit=Distance::Euklidesaowa;
}

FAPGF::~FAPGF()
{
    if(aux_table5!=nullptr)
    {
        for(int i=0;i<image_size[0]-2*delay;++i)
            delete[] aux_table5[i];

        delete[]aux_table5;
    }

    if(aux_table7!=nullptr)
    {
        for(int i=0;i<image_size[0]-2*delay;++i)
            delete[] aux_table7[i];

        delete[]aux_table7;
    }

    if(aux_table9!=nullptr)
    {
        for(int i=0;i<image_size[0]-2*delay;++i)
            delete[] aux_table9[i];

        delete[]aux_table9;
    }

    if(aux_table11!=nullptr)
    {
        for(int i=0;i<image_size[0]-2*delay;++i)
            delete[] aux_table11[i];

        delete[]aux_table11;
    }

    if(aux_b_table5!=nullptr)
    {
        for(int i=0;i<image_size[0]-2*delay;++i)
            delete[] aux_b_table5[i];

        delete[]aux_b_table5;
    }

    if(aux_b_table7!=nullptr)
    {
        for(int i=0;i<image_size[0]-2*delay;++i)
            delete[] aux_b_table7[i];

        delete[]aux_b_table7;
    }

    if(aux_b_table9!=nullptr)
    {
        for(int i=0;i<image_size[0]-2*delay;++i)
            delete[] aux_b_table9[i];

        delete[]aux_b_table9;
    }

    if(aux_b_table11!=nullptr)
    {
        for(int i=0;i<image_size[0]-2*delay;++i)
            delete[] aux_b_table11[i];

        delete[]aux_b_table11;
    }
}

bool FAPGF::set_d_parameter(float parameter)
{
    if(noise_map!=nullptr)
    {
            delete [] noise_map[0];
            delete [] noise_map;
    }

    if(measure_type_unit==Distance::Euklidesaowa)
    {
        d_parameter=parameter*255*1.73;
    }
    else
    {
        d_parameter=parameter*255;
    }
        return true;

}

float FAPGF::get_d_parameter()
{
    if(measure_type_unit==Distance::Euklidesaowa)
        return (d_parameter*1.0/(255*1.73));
    else
        return 0;
}


bool FAPGF::detect()
{
  if(R!=nullptr)
  {
      if(Type_of_noise==Noise_Type::CTRI)
      {
          if(!aux_tab_is_calculated)
              calculate_distances();

          int dobry_sasiad=0;

          noise_map=new bool*[image_size[0]];
          noise_map[0]=new bool[image_size[0]*image_size[1]];


          for(int i=1;i<image_size[0];++i)
              noise_map[i]=&noise_map[0][i*image_size[1]];

          switch(filtration_window_size)
          {
            case(5):
            {
                for(int i=0;i<image_size[0]-2*delay;++i)
                {
                    for(int j=0;j<image_size[1]-2*delay;++j)
                    {
                        for(int z=0;z<filtration_window_size;++z)
                        {
                            for(int y=0;y<filtration_window_size;++y)
                            {
                                if(aux_table5[i][j][z][y]<d_parameter)
                                    ++dobry_sasiad;
                            }
                        }

                        if(dobry_sasiad<3)
                            noise_map[i+delay][j+delay]=true;
                        else
                           noise_map[i+delay][j+delay]=false;

                         dobry_sasiad=0;
                     }
                }
             } break;

             case(7):
             {
                 for(int i=0;i<image_size[0]-2*delay;++i)
                 {
                    for(int j=0;j<image_size[1]-2*delay;++j)
                    {
                        for(int z=0;z<filtration_window_size;++z)
                        {
                            for(int y=0;y<filtration_window_size;++y)
                            {
                                if(aux_table7[i][j][z][y]<d_parameter)
                                    ++dobry_sasiad;
                            }
                        }

                        if(dobry_sasiad<3)
                        {
                            noise_map[i+delay][j+delay]=true;
                        }
                        else
                            noise_map[i+delay][j+delay]=false;

                       dobry_sasiad=0;
                    }
                }
            }break;

            case(9):
            {
                for(int i=0;i<image_size[0]-2*delay;++i)
                {
                    for(int j=0;j<image_size[1]-2*delay;++j)
                    {
                        for(int z=0;z<filtration_window_size;++z)
                        {
                            for(int y=0;y<filtration_window_size;++y)
                            {
                                if(aux_table9[i][j][z][y]<d_parameter)
                                    ++dobry_sasiad;
                             }
                        }

                        if(dobry_sasiad<3)
                        {
                            noise_map[i+delay][j+delay]=true;
                        }
                        else
                        noise_map[i+delay][j+delay]=false;

                        dobry_sasiad=0;
                    }
                }
            } break;

            case(11):
            {
                for(int i=0;i<image_size[0]-2*delay;++i)
                {
                    for(int j=0;j<image_size[1]-2*delay;++j)
                    {
                        for(int z=0;z<filtration_window_size;++z)
                        {
                            for(int y=0;y<filtration_window_size;++y)
                            {
                                if(aux_table11[i][j][z][y]<d_parameter)
                                    ++dobry_sasiad;
                            }
                        }

                        if(dobry_sasiad<3)
                            noise_map[i+delay][j+delay]=true;
                        else
                            noise_map[i+delay][j+delay]=false;

                        dobry_sasiad=0;
                     }
                }
            } break;
        }

            for (int i = 0; i<delay; ++i)
                for (int j = delay; j<image_size[1] - delay; ++j)
                    noise_map[i][j] = noise_map[2 * delay - i][j];

            for (int i =0; i<delay; ++i)
                for (int j = delay; j<image_size[1] - delay; ++j)
                    noise_map[image_size[0]-delay+i][j] = noise_map[image_size[0] -delay-2-i][j];

            for (int i = 0; i<image_size[0]; ++i)
                for (int j = 0; j<delay; ++j)
                    noise_map[i][j] = noise_map[i][2 * delay - j];

            for (int i = 0; i<image_size[0]; ++i)
                for (int j = 0; j<delay; ++j)
                    noise_map[i][image_size[1]-delay+j] = noise_map[i][image_size[1] - delay - j - 2];
            return true;
        }
        else
        {

            if(!aux_tab_is_calculated)
                calculate_distances();

            int dobry_sasiad=0;
/*
            noise_map=new bool*[image_size[0]];
            noise_map[0]=new bool[image_size[0]*image_size[1]];

            for(int i=1;i<image_size[0];++i)
                noise_map[i]=&noise_map[0][i*image_size[1]];

                */
            switch(filtration_window_size)
            {
                case(5):
                {
                    aux_b_table5= new ArrayB5*[image_size[0]-2*delay];

                    for(int i=0;i<image_size[0]-2*delay;++i)
                        aux_b_table5[i]=new ArrayB5[image_size[1]-2*delay];              

                    for(int i=0;i<image_size[0]-2*delay;++i)
                    {
                        for(int j=0;j<image_size[1]-2*delay;++j)
                        {
                          for(int z=0;z<filtration_window_size;++z)
                          {
                            for(int y=0;y<filtration_window_size;++y)
                            {
                                if(y==delay&&z==delay)
                                {
                                    aux_b_table5[i][j][z][y]=false;
                                    continue;
                                }

                                 if(aux_table5[i][j][z][y]<d_parameter)
                                 {
                                    ++dobry_sasiad;
                                    aux_b_table5[i][j][z][y]=true;
                                 }
                                 else
                                    aux_b_table5[i][j][z][y]=false;

                            }
                          }

                          /*
                          if(dobry_sasiad<3)
                            noise_map[i+delay][j+delay]=true;
                          else
                            noise_map[i+delay][j+delay]=false;
                            */
                          dobry_sasiad=0;
                        }
                     }
                  } break;

                  case(7):
                  {
                     aux_b_table7= new ArrayB7*[image_size[0]-2*delay];
                     for(int i=0;i<image_size[0]-2*delay;++i)
                        aux_b_table7[i]=new ArrayB7[image_size[1]-2*delay];

                     for(int i=0;i<image_size[0]-2*delay;++i)
                     {
                        for(int j=0;j<image_size[1]-2*delay;++j)
                        {
                            for(int z=0;z<filtration_window_size;++z)
                            {
                                for(int y=0;y<filtration_window_size;++y)
                                {
                                    if(z==delay&&y==delay)
                                        continue;

                                    if(aux_table7[i][j][z][y]<d_parameter)
                                     {
                                        aux_b_table7[i][j][z][y]=true;
                                        ++dobry_sasiad;
                                     }
                                     else
                                        aux_b_table7[i][j][z][y]=false;
                                }
                                /*
                                if(dobry_sasiad<3)
                                    noise_map[i+delay][j+delay]=true;
                                else
                                    noise_map[i+delay][j+delay]=false;

                                    */
                                dobry_sasiad=0;
                            }
                        }
                     }
                 }break;

                 case(9):
                 {
                    aux_b_table9= new ArrayB9*[image_size[0]-2*delay];

                    for(int i=0;i<image_size[0]-2*delay;++i)
                        aux_b_table9[i]=new ArrayB9[image_size[1]-2*delay];

                    for(int i=0;i<image_size[0]-2*delay;++i)
                    {
                        for(int j=0;j<image_size[1]-2*delay;++j)
                        {
                            for(int z=0;z<filtration_window_size;++z)
                            {
                                for(int y=0;y<filtration_window_size;++y)
                                {
                                    if(z==delay&&y==delay)
                                        continue;

                                    if(aux_table9[i][j][z][y]<d_parameter)
                                    {
                                        ++dobry_sasiad;
                                        aux_b_table9[i][j][z][y]=true;
                                    }
                                    else
                                        aux_b_table9[i][j][z][y]=false;

                                }
                             }
                            /*

                             if(dobry_sasiad<3)
                                noise_map[i+delay][j+delay]=true;
                             else
                                noise_map[i+delay][j+delay]=false;

                                */
                             dobry_sasiad=0;
                         }
                     }
                  } break;

                  case(11):
                  {
                    aux_b_table11= new ArrayB11*[image_size[0]-2*delay];

                    for(int i=0;i<image_size[0]-2*delay;++i)
                        aux_b_table11[i]=new ArrayB11[image_size[1]-2*delay];

                    for(int i=0;i<image_size[0]-2*delay;++i)
                    {
                        for(int j=0;j<image_size[1]-2*delay;++j)
                        {
                            for(int z=0;z<filtration_window_size;++z)
                            {
                                for(int y=0;y<filtration_window_size;++y)
                                {
                                    if(z==delay&&y==delay)
                                        continue;

                                    if(aux_table11[i][j][z][y]<d_parameter)
                                    {
                                        ++dobry_sasiad;
                                        aux_b_table11[i][j][z][y]=true;
                                    }
                                    else
                                        aux_b_table11[i][j][z][y]=false;
                                    }
                                }
/*
                                if(dobry_sasiad<3)
                                    noise_map[i+delay][j+delay]=true;
                                else
                                    noise_map[i+delay][j+delay]=false;
*/
                                dobry_sasiad=0;
                            }
                        }
                   } break;
                }
/*
                for (int i = 0; i<delay; ++i)
                    for (int j = delay; j<image_size[1] - delay; ++j)
                        noise_map[i][j] = noise_map[2 * delay - i][j];

                for (int i =0; i<delay; ++i)
                    for (int j = delay; j<image_size[1] - delay; ++j)
                        noise_map[image_size[0]-delay+i][j] = noise_map[image_size[0] -delay-2-i][j];

                for (int i = 0; i<image_size[0]; ++i)
                    for (int j = 0; j<delay; ++j)
                        noise_map[i][j] = noise_map[i][2 * delay - j];

                for (int i = 0; i<image_size[0]; ++i)
                    for (int j = 0; j<delay; ++j)
                        noise_map[i][image_size[1]-delay+j] = noise_map[i][image_size[1] - delay - j - 2];
*/
               return true;
           }
       }
    return false;
}

bool FAPGF::filter()
{
   return false;
}


bool FAPGF::detect_and_filter()
{
        return false;
}

bool FAPGF::calculate_distances()
{
    if(R!=nullptr&&measure_type_unit==Distance::Euklidesaowa)
    {

        const int horizontal =image_size[0]-2*delay;
        const int vertical= image_size[1]-2*delay;

        if(!aux_tab_is_calculated)
        {
            switch(filtration_window_size)
            {
                case(5):
                {
                    aux_table5=new Array5*[horizontal];

                    for(int i=0;i<horizontal;++i)
                        aux_table5[i]=new Array5[vertical];


                    for(int i=delay;i<image_size[0]-delay;++i)
                    {
                        for(int j=delay;j<image_size[1]-delay;++j)
                        {
                            for(int z=i-delay;z<i+delay+1;++z)
                            {
                                for(int y=j-delay;y<j+delay+1;++y)
                                {
                                       aux_table5[i-delay][j-delay][z-i+delay][y-j+delay] = sqrt((R[z][y]- R[i][j])*(R[z][y]- R[i][j])+(G[z][y]- G[i][j])*(G[z][y]- G[i][j])+(B[z][y]- B[i][j])*(B[z][y]- B[i][j]));
                                }
                            }
                        }
                    }

                    aux_tab_is_calculated=true;

                } break;

                case(7):
                {
                    aux_table7=new Array7*[horizontal];

                    for(int i=0;i<horizontal;++i)
                        aux_table7[i]=new Array7[vertical];

                    for(int i=delay;i<image_size[0]-delay;++i)
                    {
                        for(int j=delay;j<image_size[1]-delay;++j)
                        {
                            for(int z=i-delay;z<i+delay+1;++z)
                            {
                                for(int y=j-delay;y<j+delay+1;++y)
                                {
                                       aux_table7[i-delay][j-delay][z-i+delay][y-j+delay] = sqrt((R[z][y]- R[i][j])*(R[z][y]- R[i][j])+(G[z][y]- G[i][j])*(G[z][y]- G[i][j])+(B[z][y]- B[i][j])*(B[z][y]- B[i][j]));
                                }
                            }
                        }
                    }

                    aux_tab_is_calculated=true;
                } break;

                case(9):
                {
                    aux_table9=new Array9*[horizontal];

                    for(int i=0;i<horizontal;++i)
                        aux_table9[i]=new Array9[vertical];

                    for(int i=delay;i<image_size[0]-delay;++i)
                    {
                        for(int j=delay;j<image_size[1]-delay;++j)
                        {
                            for(int z=i-delay;z<i+delay+1;++z)
                            {
                                for(int y=j-delay;y<j+delay+1;++y)
                                {
                                       aux_table9[i-delay][j-delay][z-i+delay][y-j+delay] = sqrt((R[z][y]- R[i][j])*(R[z][y]- R[i][j])+(G[z][y]- G[i][j])*(G[z][y]- G[i][j])+(B[z][y]- B[i][j])*(B[z][y]- B[i][j]));
                                }
                            }
                        }
                    }

                    aux_tab_is_calculated=true;
                } break;

                case(11):
                {
                    aux_table11=new Array11*[horizontal];

                    for(int i=0;i<horizontal;++i)
                        aux_table11[i]=new Array11[vertical];

                    for(int i=delay;i<image_size[0]-delay;++i)
                    {
                        for(int j=delay;j<image_size[1]-delay;++j)
                        {
                            for(int z=i-delay;z<i+delay+1;++z)
                            {
                                for(int y=j-delay;y<j+delay+1;++y)
                                {
                                       aux_table11[i-delay][j-delay][z-i+delay][y-j+delay] = sqrt((R[z][y]- R[i][j])*(R[z][y]- R[i][j])+(G[z][y]- G[i][j])*(G[z][y]- G[i][j])+(B[z][y]- B[i][j])*(B[z][y]- B[i][j]));
                                }
                            }
                        }
                    }

                    aux_tab_is_calculated=true;

                } break;
            }
        }

        return true;
    }
    else if(R!=nullptr&&measure_type_unit==Distance::Czybyszewa)
    {
        const int horizontal =image_size[0]-2*delay;
        const int vertical= image_size[1]-2*delay;


        if(!aux_tab_is_calculated)
        {
            switch(filtration_window_size)
            {
                case(5):
                {
                    aux_table5=new Array5*[horizontal];

                    for(int i=0;i<horizontal;++i)
                        aux_table5[i]=new Array5[vertical];

                    for(int i=delay;i<image_size[0]-delay;++i)
                    {
                        for(int j=delay;j<image_size[1]-delay;++j)
                        {
                            for(int z=i-delay;z<i+delay+1;++z)
                            {
                                for(int y=j-delay;y<j+delay+1;++y)
                                {
                                       aux_table5[i-delay][j-delay][z-i+delay][y-j+delay] = std::max(std::max(abs(R[z][y]- R[i][j]),abs(G[z][y]- G[i][j])),abs(B[z][y]- B[i][j]));
                                }
                            }
                        }
                    }

                    aux_tab_is_calculated=true;

                } break;

                case(7):
                {
                    aux_table7=new Array7*[horizontal];

                    for(int i=0;i<horizontal;++i)
                        aux_table7[i]=new Array7[vertical];

                    for(int i=delay;i<image_size[0]-delay;++i)
                    {
                        for(int j=delay;j<image_size[1]-delay;++j)
                        {
                            for(int z=i-delay;z<i+delay+1;++z)
                            {
                                for(int y=j-delay;y<j+delay+1;++y)
                                {
                                       aux_table7[i-delay][j-delay][z-i+delay][y-j+delay] = std::max(std::max(abs(R[z][y]- R[i][j]),abs(G[z][y]- G[i][j])),abs(B[z][y]- B[i][j]));
                                }
                            }
                        }
                    }

                    aux_tab_is_calculated=true;

                } break;

                case(9):
                {
                    aux_table9=new Array9*[horizontal];

                    for(int i=0;i<horizontal;++i)
                        aux_table9[i]=new Array9[vertical];

                    for(int i=delay;i<image_size[0]-delay;++i)
                    {
                        for(int j=delay;j<image_size[1]-delay;++j)
                        {
                            for(int z=i-delay;z<i+delay+1;++z)
                            {
                                for(int y=j-delay;y<j+delay+1;++y)
                                {
                                       aux_table9[i-delay][j-delay][z-i+delay][y-j+delay]= std::max(std::max(abs(R[z][y]- R[i][j]),abs(G[z][y]- G[i][j])),abs(B[z][y]- B[i][j]));
                                }
                            }
                        }
                    }

                    aux_tab_is_calculated=true;


                } break;


                case(11):
                {
                    aux_table11=new Array11*[horizontal];

                    for(int i=0;i<horizontal;++i)
                        aux_table11[i]=new Array11[vertical];

                    for(int i=delay;i<image_size[0]-delay;++i)
                    {
                        for(int j=delay;j<image_size[1]-delay;++j)
                        {
                            for(int z=i-delay;z<i+delay+1;++z)
                            {
                                for(int y=j-delay;y<j+delay+1;++y)
                                {
                                       aux_table11[i-delay][j-delay][z-i+delay][y-j+delay] = std::max(std::max(abs(R[z][y]- R[i][j]),abs(G[z][y]- G[i][j])),abs(B[z][y]- B[i][j]));
                                }
                            }
                        }
                    }

                    aux_tab_is_calculated=true;

                } break;
            }

        }

        return true;
    }
     else
        return false;
}


bool FAPGF::optimize_d_parameter(bool ** pointer,float step)
{

    if(R!=nullptr)
    {
        if(!aux_tab_is_calculated)
            calculate_distances();

        float most_accurate_d_parameter=0;
        float accuracy=0;

        this->set_d_parameter(0);
        this->detect();
            accuracy=this->Accuracy(pointer);

        for(float i=step;i<=1;i+=step)
        {
            this->set_d_parameter(i);
                this->detect();

                float temporary_accuracy = Accuracy(pointer);

                if(temporary_accuracy>accuracy)
                {
                    accuracy=temporary_accuracy;

                    most_accurate_d_parameter=i;
                }
            }
            this->set_d_parameter(most_accurate_d_parameter);

            return true;
    }
    else
       return false;
}


void FAPGF::set_distance_type_unit(Distance type)
{
    measure_type_unit=type;
}

bool FAPGF::Clean_Aux_Table()
{
    switch (filtration_window_size)
    {
        case(5):
        {
            for(int i=0;i<image_size[0]-2*delay;++i)
                delete[] aux_table5[i];

            delete[] aux_table5;

            aux_table5=nullptr;

        } break;

        case(7):
        {
            for(int i=0;i<image_size[0]-2*delay;++i)
                delete[] aux_table7[i];

            delete[] aux_table7;

            aux_table7=nullptr;

        } break;

        case(9):
        {
            for(int i=0;i<image_size[0]-2*delay;++i)
                delete[] aux_table9[i];

            delete[] aux_table9;

            aux_table9=nullptr;

        } break;


        case(11):
        {
            for(int i=0;i<image_size[0]-2*delay;++i)
                delete[] aux_table11[i];

            delete[] aux_table11;

            aux_table11=nullptr;

        } break;

    }

   aux_tab_is_calculated=false;
 return true;
}






