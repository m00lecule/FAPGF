#ifndef FAPGF_H
#define FAPGF_H

#include <QObject>
#include <qfilter.h>
#include <QImage>
#include <QFile>
#include <QTextStream>
#include <algorithm>

typedef double Array5[5][5];
typedef bool ArrayB5[5][5];

typedef double Array7[7][7];
typedef bool ArrayB7[7][7];

typedef double Array9[9][9];
typedef bool ArrayB9[9][9];

typedef double Array11[11][11];
typedef bool ArrayB11[11][11];

enum class Distance{Czybyszewa, Euklidesaowa};
enum class Noise_Type{CTRI,GaussNoise};

class FAPGF: public QFilter
{
public:
    FAPGF();
    FAPGF(double**,double**,double**,int,int, unsigned short,Noise_Type);
    FAPGF(QImage&,unsigned short,Noise_Type);
    ~FAPGF();

    void set_distance_type_unit(Distance type);
    bool optimize_d_parameter(bool**,float);
    bool set_d_parameter(float const);
    QImage get_image() const {return images;}
    float get_d_parameter();
    bool detect();
    bool calculate_distances();
    bool filter();
    bool detect_and_filter();
    bool Clean_Aux_Table();

    ArrayB5** get_aux_b_table5() const { return aux_b_table5; }
    ArrayB7** get_aux_b_table7() const { return aux_b_table7; }
    ArrayB9** get_aux_b_table9() const { return aux_b_table9; }
    ArrayB11** get_aux_b_table11() const { return aux_b_table11; }

private:
    bool aux_tab_is_calculated;

    Array5** aux_table5;
    ArrayB5** aux_b_table5;

    Array7** aux_table7;
    ArrayB7** aux_b_table7;

    Array9** aux_table9;
    ArrayB9** aux_b_table9;

    Array11** aux_table11;
    ArrayB11** aux_b_table11;

    float d_parameter;
    QImage images;
    Distance measure_type_unit;
    Noise_Type Type_of_noise;

};

#endif // FAPGF_H
