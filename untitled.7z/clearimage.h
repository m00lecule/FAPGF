#ifndef CLEARIMAGE_H
#define CLEARIMAGE_H
#include "averagefilter.h"
#include <qimage.h>

class ClearImage : public QFilter
{
public:
    ClearImage();
    ClearImage(QImage&,unsigned short);


    double calculate_MSE(double**,double**,double**);
    double calculate_PSNR(double**,double**,double**);
    double calculate_NCD(double**,double**,double**);

    bool detect() {return false;}
    bool filter() {return false;}
    bool detect_and_filter() {return false;}


};

#endif // CLEARIMAGE_H
