#ifndef AVERAGEFILTER_H
#define AVERAGEFILTER_H
#include "qfilter.h"
#include "vmf.h"
#include "clearimage.h"
#include "fapgf.h"

using namespace std;

class AverageFilter : public QFilter
{
public:
    AverageFilter();
    AverageFilter(QImage&,bool**,double);
    QImage& get_repaired_image() { return repaired_image; }
    bool filter();
    bool filterALL(FAPGF*);
    bool detect();
    bool detect_and_filter();


    friend class ClearImage;

private:
    QImage repaired_image;
};

#endif // AVERAGEFILTER_H
