#include "averagefilter.h"

AverageFilter::AverageFilter():QFilter()
{
}

AverageFilter::AverageFilter(QImage& Image,bool** map, double value):QFilter(Image,value,map), repaired_image(Image)
{
}

bool AverageFilter::filter()
{
    if(R!=nullptr&&noise_map!=nullptr)
    {
            double average_r;
            double average_g;
            double average_b;
            int index;

            for(int i=delay;i<image_size[0]-delay;++i)
            {
                for(int j=delay;j<image_size[1]-delay;++j)
                {
                     average_b=0;
                     average_g=0;
                     average_r=0;
                     index=0;

                     QColor color;
                     if(noise_map[i][j])
                     {
                        for(int x=i-delay;x<i+delay+1;++x)
                            for(int y=j-delay;y<j+delay+1;++y)
                                {
                                    if(!noise_map[x][y])
                                    {
                                        average_b+=B[x][y];
                                        average_r+=R[x][y];
                                        average_g+=G[x][y];
                                        ++index;

                                    }

                                }

                        if(index!=0)
                        {
                            R[i][j]=round(average_r/index);
                            G[i][j]=round(average_g/index);
                            B[i][j]=round(average_b/index);

                            color.setRed(round(average_r/index));
                            color.setGreen(round(average_g/index));
                            color.setBlue(round(average_b/index));

                        }
                        else
                        {
                            VMF vmf(i,j,R,G,B,this->filtration_window_size);
                            vmf.filter();

                            R[i][j]=vmf.get_red();
                            G[i][j]=vmf.get_green();
                            B[i][j]=vmf.get_blue();


                            color.setRed(R[i][j]);
                            color.setGreen(G[i][j]);
                            color.setBlue(B[i][j]);
                        }
                        repaired_image.setPixelColor(i-delay,j-delay,color);
                    }
                }
            }
            return true;
    }
    else
        return false;

}

bool AverageFilter::filterALL(FAPGF*fapgf)
{
    if(fapgf!=nullptr)
    {

        switch(fapgf->get_filtration_window_size())
        {
            case(5):
            {
                double average_r;
                double average_g;
                double average_b;
                int index;

                ArrayB5**temporary_pointer=fapgf->get_aux_b_table5();

                for(int i=delay;i<image_size[0]-delay;++i)
                {
                    for(int j=delay;j<image_size[1]-delay;++j)
                    {
                         average_b=0;
                         average_g=0;
                         average_r=0;
                         index=0;


                         QColor color;

                         for(int x=i-delay;x<i+delay+1;++x)
                             for(int y=j-delay;y<j+delay+1;++y)
                                    {
                                        if(temporary_pointer[i-delay][j-delay][x-i+delay][y-j+delay]==true)
                                        {
                                            average_b+=B[x][y];
                                            average_r+=R[x][y];
                                            average_g+=G[x][y];
                                            ++index;
                                        }

                                    }

                            if(index!=0)
                            {
                                R[i][j]=round(average_r/index);
                                G[i][j]=round(average_g/index);
                                B[i][j]=round(average_b/index);

                                color.setRed(round(average_r/index));
                                color.setGreen(round(average_g/index));
                                color.setBlue(round(average_b/index));

                            }
                            else
                            {
                                VMF vmf(i,j,R,G,B,this->filtration_window_size);
                                vmf.filter();

                                R[i][j]=vmf.get_red();
                                G[i][j]=vmf.get_green();
                                B[i][j]=vmf.get_blue();


                                color.setRed(R[i][j]);
                                color.setGreen(G[i][j]);
                                color.setBlue(B[i][j]);
                            }

                            repaired_image.setPixelColor(i-delay,j-delay,color);
                     }
                }
                return true;
            } break;

            case(7):
            {
            double average_r;
            double average_g;
            double average_b;
            int index;

            ArrayB7**temporary_pointer=fapgf->get_aux_b_table7();

            for(int i=delay;i<image_size[0]-delay;++i)
            {
                for(int j=delay;j<image_size[1]-delay;++j)
                {
                     average_b=0;
                     average_g=0;
                     average_r=0;
                     index=0;


                     QColor color;

                     for(int x=i-delay;x<i+delay+1;++x)
                         for(int y=j-delay;y<j+delay+1;++y)
                                {
                                    if(temporary_pointer[i-delay][j-delay][x-i+delay][y-j+delay]==true)
                                    {
                                        average_b+=B[x][y];
                                        average_r+=R[x][y];
                                        average_g+=G[x][y];
                                        ++index;
                                    }

                                }

                        if(index!=0)
                        {
                            R[i][j]=round(average_r/index);
                            G[i][j]=round(average_g/index);
                            B[i][j]=round(average_b/index);

                            color.setRed(round(average_r/index));
                            color.setGreen(round(average_g/index));
                            color.setBlue(round(average_b/index));

                        }
                        else
                        {
                            VMF vmf(i,j,R,G,B,this->filtration_window_size);
                            vmf.filter();

                            R[i][j]=vmf.get_red();
                            G[i][j]=vmf.get_green();
                            B[i][j]=vmf.get_blue();


                            color.setRed(R[i][j]);
                            color.setGreen(G[i][j]);
                            color.setBlue(B[i][j]);
                        }
                        repaired_image.setPixelColor(i-delay,j-delay,color);
                 }
            }
            return true;


            } break;


            case(9):
            {
                double average_r;
                double average_g;
                double average_b;
                int index;

                ArrayB9**temporary_pointer=fapgf->get_aux_b_table9();

                for(int i=delay;i<image_size[0]-delay;++i)
                {
                    for(int j=delay;j<image_size[1]-delay;++j)
                    {
                         average_b=0;
                         average_g=0;
                         average_r=0;
                         index=0;


                         QColor color;
                         for(int x=i-delay;x<i+delay+1;++x)
                             for(int y=j-delay;y<j+delay+1;++y)
                                    {
                                        if(temporary_pointer[i-delay][j-delay][x-i+delay][y-j+delay]==true)
                                        {
                                            average_b+=B[x][y];
                                            average_r+=R[x][y];
                                            average_g+=G[x][y];
                                            ++index;
                                        }

                                    }

                            if(index!=0)
                            {
                                R[i][j]=round(average_r/index);
                                G[i][j]=round(average_g/index);
                                B[i][j]=round(average_b/index);

                                color.setRed(round(average_r/index));
                                color.setGreen(round(average_g/index));
                                color.setBlue(round(average_b/index));

                            }
                            else
                            {
                                VMF vmf(i,j,R,G,B,this->filtration_window_size);
                                vmf.filter();

                                R[i][j]=vmf.get_red();
                                G[i][j]=vmf.get_green();
                                B[i][j]=vmf.get_blue();


                                color.setRed(R[i][j]);
                                color.setGreen(G[i][j]);
                                color.setBlue(B[i][j]);
                            }
                            repaired_image.setPixelColor(i-delay,j-delay,color);
                     }
                }
                return true;
            } break;

            case(11):
            {
                double average_r;
                double average_g;
                double average_b;
                int index;

                ArrayB11**temporary_pointer=fapgf->get_aux_b_table11();

                for(int i=delay;i<image_size[0]-delay;++i)
                {
                    for(int j=delay;j<image_size[1]-delay;++j)
                    {
                         average_b=0;
                         average_g=0;
                         average_r=0;
                         index=0;


                         QColor color;

                         for(int x=i-delay;x<i+delay+1;++x)
                             for(int y=j-delay;y<j+delay+1;++y)
                                    {
                                        if(temporary_pointer[i-delay][j-delay][x-i+delay][y-j+delay]==true)
                                        {
                                            average_b+=B[x][y];
                                            average_r+=R[x][y];
                                            average_g+=G[x][y];
                                            ++index;
                                        }

                                    }

                            if(index!=0)
                            {
                                R[i][j]=round(average_r/index);
                                G[i][j]=round(average_g/index);
                                B[i][j]=round(average_b/index);

                                color.setRed(round(average_r/index));
                                color.setGreen(round(average_g/index));
                                color.setBlue(round(average_b/index));

                            }
                            else
                            {
                                VMF vmf(i,j,R,G,B,this->filtration_window_size);
                                vmf.filter();

                                R[i][j]=vmf.get_red();
                                G[i][j]=vmf.get_green();
                                B[i][j]=vmf.get_blue();


                                color.setRed(R[i][j]);
                                color.setGreen(G[i][j]);
                                color.setBlue(B[i][j]);
                            }
                            repaired_image.setPixelColor(i-delay,j-delay,color);
                     }
                }
                return true;
            } break;
        }
        return true;
    }
    else
        return false;
}


bool AverageFilter::detect_and_filter()
{
    return false;
}

bool AverageFilter::detect()
{
    return false;
}





