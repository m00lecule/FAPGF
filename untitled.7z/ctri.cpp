#include "ctri.h"
#include <QFile>
#include <QTextStream>
#include <QString>
#include <random>

CTRI::CTRI() : density(0), map_of_noise(nullptr)
{
    image_size[0]=0;
    image_size[1]=0;
}

CTRI::CTRI(double parameter) : map_of_noise(nullptr)
{
    image_size[0]=0;
    image_size[1]=0;

    if(parameter>=1&&parameter<=100)
        density=parameter/100;
    else
        density=0;
}

bool CTRI::Disturb(QImage & Image)
{
        image_size[0]=Image.width();
        image_size[1]=Image.height();

        if(map_of_noise!=nullptr)
        {
            delete [] map_of_noise[0];
            delete [] map_of_noise;
        }

        int how_many=round(density*image_size[0]*image_size[1]);

        map_of_noise=new bool *[image_size[0]];
        map_of_noise[0]=new bool[image_size[0]*image_size[1]];

        for(int i=1;i<image_size[0];++i)
            map_of_noise[i]=&map_of_noise[0][i*image_size[1]];

        for(int i=0;i<image_size[0];++i)
        {
            for(int j=0;j<image_size[1];++j)
                map_of_noise[i][j]=false;
        }

        QColor color;

       int*position= new int[image_size[0]*image_size[1]];

       for(int i=0;i<image_size[0]*image_size[1];++i)
       {
           *(position+i)=i;
       }

        int index =0;

        std::mt19937 mt(time(0));
        std::uniform_int_distribution<int> cw(0,255);

        for(int i=0;i<how_many;++i)
        {
            std::uniform_int_distribution<int> dist(0,(image_size[0]*image_size[1])-i-1);

            index = dist(mt);

            int drawn= *(position+index);

            color.setBlue(cw(mt));
            color.setRed(cw(mt));
            color.setGreen(cw(mt));

            map_of_noise[drawn%image_size[0]][(int)floor(drawn/image_size[0])]=true;

            Image.setPixelColor(drawn%image_size[0],floor(drawn/image_size[0]),color);
            *(position+index)=*(position+(image_size[0]*image_size[1])-i-1);
        }

        delete [] position;

        return true;
}

bool CTRI::save_map_to_txt_file()
{
    if(map_of_noise==nullptr)
    {
        return false;
    }
    else
    {
        QFile File("C:\\Users\\michaldygaz\\Desktop\\CTRI.txt");
        QTextStream out(&File);
        File.open(QFile::WriteOnly|QFile::Text);
        QString Message;

        for(int i=0;i<image_size[0];++i)
        {
            for(int j=0;j<image_size[1];++j)
            {
                if(map_of_noise[i][j])
                    Message+=(QString::number(1,'f',0));
                else
                    Message+=(QString::number(0,'f',0));
            }

            out<<Message;
            Message="";
        }
        return true;
    }
}

