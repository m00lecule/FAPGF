#include "qfilter.h"
#include <QFile>
#include <QTextStream>
#include <QString>
#include <QVariant>
#include <QDebug>

QFilter::QFilter() : R(nullptr),G(nullptr),B(nullptr),noise_map(nullptr),filtration_window_size(0), delay(0),X(nullptr),Y(nullptr),Z(nullptr),CIE_l(nullptr),CIE_b(nullptr),CIE_a(nullptr)
{
    image_size[0]=0;
    image_size[1]=0;
}

QFilter::QFilter(QImage & Image,unsigned short size_of_filtering_window,bool**map):noise_map(map),filtration_window_size(size_of_filtering_window),X(nullptr),Y(nullptr),Z(nullptr),CIE_l(nullptr),CIE_b(nullptr),CIE_a(nullptr)
{
     delay=floor(filtration_window_size/2);

    image_size[0]=Image.width()+2*delay;
    image_size[1]=Image.height()+2*delay;

    QColor color;

    R=new double*[image_size[0]];
    G=new double*[image_size[0]];
    B=new double*[image_size[0]];

    R[0]=new double[image_size[0]*image_size[1]];
    G[0]=new double[image_size[0]*image_size[1]];
    B[0]=new double[image_size[0]*image_size[1]];

    for(int i=1;i<image_size[0];++i)
    {
        R[i]=&R[0][i*image_size[1]];
        G[i]=&G[0][i*image_size[1]];
        B[i]=&B[0][i*image_size[1]];
    }

    for (int i = delay; i<image_size[0] - delay; ++i)
        {
            for (int j = delay; j<image_size[1] - delay; ++j)
            {
                color=Image.pixelColor(i-delay,j-delay);

                R[i][j]=color.red();
                G[i][j]=color.green();
                B[i][j]=color.blue();
            }
        }

    for (int i = 0; i<delay; ++i)
        {
            for (int j = delay; j<image_size[1] - delay; ++j)
            {
                R[i][j] = R[2 * delay - i][j];
                G[i][j] = G[2 * delay - i][j];
                B[i][j] = B[2 * delay - i][j];
            }
        }


    for (int i =0; i<delay; ++i)
        {
            for (int j = delay; j<image_size[1] - delay; ++j)
            {
                R[image_size[0]-delay+i][j] = R[image_size[0] -delay-2-i][j];
                G[image_size[0]-delay+i][j] = G[image_size[0] -delay-2-i][j];
                B[image_size[0]-delay+i][j] = B[image_size[0] -delay-2-i][j];
            }

        }


    for (int i = 0; i<image_size[0]; ++i)
        {
            for (int j = 0; j<delay; ++j)
            {
                R[i][j] = R[i][2 * delay - j];
                G[i][j] = G[i][2 * delay - j];
                B[i][j] = B[i][2 * delay - j];
            }
        }

    for (int i = 0; i<image_size[0]; ++i)
        {
            for (int j = 0; j<delay; ++j)
            {
                R[i][image_size[1]-delay+j] = R[i][image_size[1] - delay - j - 2];
                G[i][image_size[1]-delay+j] = G[i][image_size[1] - delay - j - 2];
                B[i][image_size[1]-delay+j] = B[i][image_size[1] - delay - j - 2];

            }
        }
}

QFilter::QFilter(double **red, double **green, double **blue,int width ,int heigth, unsigned short frame) :filtration_window_size(frame), noise_map(nullptr),delay(floor(frame/2)),X(nullptr),Y(nullptr),Z(nullptr),CIE_l(nullptr),CIE_b(nullptr),CIE_a(nullptr)
{
    image_size[0]=width;
    image_size[1]=heigth;


    R=new double*[width];
    G=new double*[width];
    B=new double*[width];

    R[0]=new double[width*heigth];
    G[0]=new double[width*heigth];
    B[0]=new double[width*heigth];

    for(int i=1;i<width;++i)
    {
        R[i]=&R[0][i*heigth];
        R[i]=&R[0][i*heigth];
        R[i]=&R[0][i*heigth];
    }


    for(int i=0;i<width;++i)
    {
        for(int j=0;j<heigth;++j)
        {
            R[i][j]=red[i][j];
            G[i][j]=green[i][j];
            B[i][j]=blue[i][j];
        }
    }
}

bool QFilter::load_the_image(QImage & Image)
{
    QImage empty;

    if(Image!=empty&&filtration_window_size!=0)
    {
        if(R==nullptr)
         {
            delete [] R[0];
            delete [] R;

            delete [] G[0];
            delete [] G;

            delete [] B[0];
            delete [] B;

         }

        delay=floor(filtration_window_size/2);

        image_size[0]=Image.width()+2*delay;
        image_size[1]=Image.height()+2*delay;

        QColor color;

        R=new double*[image_size[0]];
        G=new double*[image_size[0]];
        B=new double*[image_size[0]];

        R[0]=new double[image_size[0]*image_size[1]];
        G[0]=new double[image_size[0]*image_size[1]];
        B[0]=new double[image_size[0]*image_size[1]];

        for(int i=1;i<image_size[0];++i)
        {
            R[i]=&R[0][i*image_size[1]];
            G[i]=&G[0][i*image_size[1]];
            B[i]=&B[0][i*image_size[1]];
        }

        for (int i = delay; i<image_size[0] - delay; ++i)
            {
                for (int j = delay; j<image_size[1] - delay; ++j)
                {
                    color=Image.pixelColor(i-delay,j-delay);

                    R[i][j]=color.red();
                    G[i][j]=color.green();
                    B[i][j]=color.blue();
                }
            }

        for (int i = 0; i<delay; ++i)
            {
                for (int j = delay; j<image_size[1] - delay; ++j)
                {
                    R[i][j] = R[2 * delay - i][j];
                    G[i][j] = G[2 * delay - i][j];
                    B[i][j] = B[2 * delay - i][j];
                }
            }


        for (int i =0; i<delay; ++i)
            {
                for (int j = delay; j<image_size[1] - delay; ++j)
                {
                    R[image_size[0]-delay+i][j] = R[image_size[0] -delay-2-i][j];
                    G[image_size[0]-delay+i][j] = G[image_size[0] -delay-2-i][j];
                    B[image_size[0]-delay+i][j] = B[image_size[0] -delay-2-i][j];
                }

            }


        for (int i = 0; i<image_size[0]; ++i)
            {
                for (int j = 0; j<delay; ++j)
                {
                    R[i][j] = R[i][2 * delay - j];
                    G[i][j] = G[i][2 * delay - j];
                    B[i][j] = B[i][2 * delay - j];
                }
            }

        for (int i = 0; i<image_size[0]; ++i)
            {
                for (int j = 0; j<delay; ++j)
                {
                    R[i][image_size[1]-delay+j] = R[i][image_size[1] - delay - j - 2];
                    G[i][image_size[1]-delay+j] = G[i][image_size[1] - delay - j - 2];
                    B[i][image_size[1]-delay+j] = B[i][image_size[1] - delay - j - 2];

                }
            }
       return true;
    }
    else
        return false;
}

QFilter::~QFilter()
{
    if(R==nullptr)
    {
        delete [] R[0];
        delete [] R;

        delete [] G[0];
        delete [] G;

        delete [] B[0];
        delete [] B;

    }

    if(noise_map!=nullptr)
    {
            delete [] noise_map[0];
            delete [] noise_map;
    }

    if(X!=nullptr)
    {
        delete [] X[0];
        delete [] X;

        delete [] Y[0];
        delete [] Y;

        delete [] Z[0];
        delete [] Z;
    }

    if(CIE_a!=nullptr)
    {
        delete [] CIE_a[0];
        delete [] CIE_a;

        delete [] CIE_l[0];
        delete [] CIE_l;

        delete [] CIE_b[0];
        delete [] CIE_b;
    }

}

bool QFilter::set_filtration_window_size(const unsigned short size)
{
    if(size%2!=0&&size!=1)
    {
        filtration_window_size=size;
        return true;
    }
    else return false;
}


double QFilter::Accuracy(bool** wskaznik)
{
        int TP=0;
        int TN=0;
        int FP=0;
        int FN=0;



       for(int i=delay;i<image_size[0]-delay;++i)
        {

            for(int j=delay;j<image_size[1]-delay;++j)
            {
               if(!wskaznik[i-delay][j-delay]&&!noise_map[i][j])
                   ++TN;
               else
               {
                   if(wskaznik[i-delay][j-delay]&&!noise_map[i][j])
                       ++FN;
                   else
                   {
                       if(!wskaznik[i-delay][j-delay]&&noise_map[i][j])
                           ++FP;
                       else
                           ++TP;

                   }
               }
            }
        }


        return (TP+TN)*1.0/(TP+TN+FP+FN);
}

bool QFilter::set_map(bool** pointer)
{
   if(pointer!=nullptr)
   {
        if(noise_map!=nullptr)
        {
            delete[] noise_map[0];
            delete[] noise_map;
        }

        noise_map=pointer;
        return true;
   }
   else
   {}

       return false;
}

bool QFilter::calculate_XYZ()
{
   if(R!=nullptr)
   {
        const int vertical = image_size[0] - filtration_window_size +1;
        const int horizontal = image_size[1] - filtration_window_size +1;


        X=new double * [vertical];
        Y=new double * [vertical];
        Z=new double * [vertical];

        X[0]=new double [vertical*horizontal];
        Y[0]=new double [vertical*horizontal];
        Z[0]=new double [vertical*horizontal];

        for(int i=1;i<vertical;++i)
        {
            X[i]=&X[0][i*horizontal];
            Y[i]=&Y[0][i*horizontal];
            Z[i]=&Z[0][i*horizontal];
        }

        for(int i=delay;i<image_size[0]-delay;++i)
        {
            for(int j=delay;j<image_size[1]-delay;++j)
            {


                double temp_R;
                double temp_G;
                double temp_B;

                   temp_R=R[i][j]/255;
                   temp_G=G[i][j]/255;
                   temp_B=B[i][j]/255;


                   if ( temp_R > 0.04045 )
                       temp_R = pow(( ( temp_R + 0.055 ) / 1.055 ), 2.4);
                   else
                       temp_R = temp_R / 12.92;


                   if ( temp_G > 0.04045 )
                       temp_G = pow(( ( temp_G + 0.055 ) / 1.055 ),2.4);
                   else
                       temp_G = temp_G / 12.92;

                   if ( temp_B > 0.04045 )
                       temp_B = pow(( ( temp_B + 0.055 ) / 1.055 ),2.4);
                   else
                       temp_B = temp_B / 12.92;

                    temp_R*=100;
                    temp_G*=100;
                    temp_B*=100;

                    X[i-delay][j-delay] = temp_R * 0.4124 + temp_G * 0.3576 + temp_B * 0.1805;
                    Y[i-delay][j-delay] = temp_R * 0.2126 + temp_G * 0.7152 + temp_B * 0.0722;
                    Z[i-delay][j-delay] = temp_R * 0.0193 + temp_G * 0.1192 + temp_B * 0.9505;
            }
        }

        return true;
   }
   else
    return false;
}

bool QFilter::convert_from_XYZ_to_CIElab()
{
    if(X==nullptr)
    {
        if(this->calculate_XYZ())
        {
            const int vertical = image_size[0] - filtration_window_size +1;
            const int horizontal = image_size[1] - filtration_window_size +1;


            CIE_a=new double * [vertical];
            CIE_b=new double * [vertical];
            CIE_l=new double * [vertical];

            CIE_a[0]=new double [vertical*horizontal];
            CIE_b[0]=new double [vertical*horizontal];
            CIE_l[0]=new double [vertical*horizontal];

            for(int i=1;i<vertical;++i)
            {
                CIE_a[i]=&X[0][i*horizontal];
                CIE_b[i]=&Y[0][i*horizontal];
                CIE_l[i]=&Z[0][i*horizontal];
            }


            for(int i=0;i<vertical;++i)
            {
                for(int j=0;j<horizontal;++j)
                {

                    double temp_X=X[i][j]/94.81;
                    double temp_Y=Y[i][j]/100.0;
                    double temp_Z=Z[i][j]/107.3;

                    if(temp_X>0.008856)
                        temp_X = pow(temp_X,1/3);
                    else
                       temp_X = (7.787*temp_X)+(16/116);

                    if(temp_Y>0.008856)
                        temp_Y = pow(temp_Y,1/3);
                    else
                        temp_Y = (7.787*temp_Y)+(16/116);


                    if(temp_Z > 0.008856)
                        temp_Z = pow(temp_Z,1/3);
                    else
                        temp_Z = (7.787*temp_Z)+(16/116);


                    CIE_l[i][j] = (116*temp_Y)-16;
                    CIE_a[i][j] = 500*(temp_X-temp_Y);
                    CIE_b[i][j] = 200*(temp_Y-temp_Z);




                }

            }

            return true;
        }
        else return false;
    }
    else return false;
}






